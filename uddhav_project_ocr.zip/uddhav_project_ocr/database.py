import sqlite3

class LocalDatabase:
    def __init__(self, db_name="database.db"):
        # Connect to SQLite database or create it if it doesn't exist
        self.connection = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.connection.cursor()
        # Create the table if it doesn't already exist
        self.create_tables()

    def create_tables(self):
        # Create tables for each type of data
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Education (
                SrNo INTEGER,
                School_University TEXT,
                Qualification TEXT,
                CGPA TEXT,
                Passout_Year TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Programs (
                Program TEXT,
                Contents TEXT,
                Organized_By TEXT,
                Duration TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Certifications (
                SrNo TEXT,
                Certification TEXT,
                Duration TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Relations (
                Relation TEXT,
                Occupation_Profession TEXT,
                Resident_Location TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Contacts (
                Name TEXT,
                Designation TEXT,
                Contact_No TEXT
            )
        ''')
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS permanent_address (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                street TEXT,
                city TEXT,
                state TEXT,
                zip_code TEXT,
                country TEXT
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS current_address (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                street TEXT,
                city TEXT,
                state TEXT,
                zip_code TEXT,
                country TEXT
            )
        ''')
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS general_details (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dob TEXT,
                age INTEGER,
                gender TEXT,
                passport TEXT,
                mobile TEXT,
                pan TEXT,
                visa TEXT,
                email TEXT,
                emergency_contact_name TEXT,
                emergency_contact_number TEXT,
                relocation TEXT
            )
        ''')
        self.connection.commit()

    def insert_data(self, table_name, data):
        # Dynamically insert data into the specified table
        keys = ', '.join(data.keys())
        placeholders = ', '.join(['?'] * len(data))
        query = f"INSERT INTO {table_name} ({keys}) VALUES ({placeholders})"
        self.cursor.execute(query, tuple(data.values()))
        self.connection.commit()


    def get_data(self, table_name):
        # Fetch all data from the specified table
        query = f"SELECT * FROM {table_name}"
        self.cursor.execute(query)
        return self.cursor.fetchall()


def fetch_all_records(table_name):
    """
    Fetch all records from the specified table in the database.

    Args:
        table_name (str): Name of the table to fetch records from.

    Returns:
        list: A list of tuples containing all rows from the table.
    """
    try:
        # Connect to the SQLite database
        connection = sqlite3.connect("database.db")
        cursor = connection.cursor()
        
        # Prepare and execute the SQL query
        query = f"SELECT * FROM {table_name}"
        cursor.execute(query)
        
        # Fetch all records
        records = cursor.fetchall()
        
        # Optionally, fetch column names for better debugging
        column_names = [description[0] for description in cursor.description]
        print(f"Columns in {table_name}: {column_names}")
        
        return records
    
    except sqlite3.Error as e:
        print(f"Error accessing table {table_name}: {e}")
        return []
    
    finally:
        # Ensure the connection is closed
        if connection:
            connection.close()

# Example usage
if __name__ == "__main__":
    table_name = "Education"  # Replace with your table name
    records = fetch_all_records(table_name)
    if records:
        print(f"Records in {table_name}:")
        for record in records:
            print(record)
    else:
        print(f"No records found in {table_name} or an error occurred.")



