## Run the follow commands in terminal

0. @ requirements 
https://github.com/tesseract-ocr/tesseract/releases/download/5.5.0/tesseract-ocr-w64-setup-5.5.0.20241111.exe
download the above file and instal it
0. python -m spacy download en_core_web_sm


1. pip install venv
2. python -m venv .venv
3. ./.venv/Scripts/activate
4. python app.py